Bibulous Module
===============

.. automodule:: bibulous
   :members:
   :undoc-members:
   :special-members:

.. autoclass:: Bibdata
   :members:

