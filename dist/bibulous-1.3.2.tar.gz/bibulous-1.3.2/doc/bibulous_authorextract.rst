bibulous_authorextract module
=============================

.. automodule:: bibulous_authorextract
   :members:
   :special-members:
   :undoc-members: